<script type = "text/javascript">
    $(document).ready(function($)
    {
        var e0 = $(document).find('.screen_data');
        var s1 = $(document).find('.screen_home').html();
        e0.html(s1)
    }
</script>