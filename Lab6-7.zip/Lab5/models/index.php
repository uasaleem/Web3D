<!-- included head -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Coca Cola</title>
  <meta content="" name="description">

  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- Models -->
  <script type='text/javascript' src='http://www.x3dom.org/x3dom/release/x3dom.js'></script>
  <link rel="stylesheet" href="http://www.x3dom.org/x3dom/release/x3dom.css">

  <!-- For x3d model showing -->
  <link rel='stylesheet' type='text/css' href='http://www.x3dom.org/x3dom/release/x3dom.css'>
  </link>
  <script type='text/javascript' src='http://www.x3dom.org/x3dom/release/x3dom.js'></script>

  <style type="text/css">
    .product .nav-item a img {
      width: 20%;
      margin-left: auto;
      margin-right: auto;
      display: flex;
    }

    .product .nav-tabs .nav-link {
      padding: 68px 0px 69px;
      background-color: lightgrey;
    }

    .product .nav-tabs .nav-link.active {
      background-color: red;
      border: 1px solid black;
    }

    .feature-box x3d {
      margin-left: auto;
      margin-right: auto;
    }

    .feature-box h3 {
      text-align: center;
    }

    .product .aos-animate {
      margin-left: 10px;
    }
  </style>
</head>

<body>
  <!-- ======= Header ======= -->
  <!-- included Navbar -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="javascript:void(0);" id="home" class="logo d-flex align-items-center">
        <!--<img src="assets/img/logo.png" alt="">-->
        <span>Coke</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link btn_menu" id="home" href="javascript:void(0);">Home</a></li>
          <li><a class="nav-link btn_menu" href="#/coke">Coke</a></li>
          <li><a class="nav-link btn_menu" href="javascript:void(0);">Sprite</a></li>
          <li><a class="nav-link btn_menu" href="javascript:void(0);">Lilt</a></li>
          <li><a class="nav-link btn_menu" id="about-us" href="javascript:void(0);">About Us</a></li>
          <li><a class="getstarted btn_menu" screen_name="extraWork" href="javascript:void(0);">Extra Work</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header>
  <!-- End Header -->



  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up">Coca Cola</h1>
          <h2 data-aos="fade-up" data-aos-delay="400">X3d models</h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <div class="text-center text-lg-start">
              <a href="#values" class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                <span>Products</span>
                <i class="bi bi-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- End Hero -->




  <main id="main">
    <!-- ======= Values Section ======= -->
    <section id="products" class="products">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Products</h2>
        </header>
        <div class="row">
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <!-- <a href="javascript:void(0);" id="first1">
                 <img src="assets/img/cocacola1.png" class="img-fluid" alt="">
               </a>  -->
              <x3d id="first" data-id="tab-nine1">
                <scene>
                  <inline url="assets/X3d/3D_models/Coke_Can/coke_can_x3d.x3d"></inline>
                </scene>
              </x3d>
              <h3>Coca Cola</h3>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
            <div class="box">
              <x3d id="second" data-id="tab-nine2">
                <scene>
                  <inline url="assets/X3d/3D_models/Lilt_can/Lilt_can_x3d.x3d"></inline>
                </scene>
              </x3d>
              <h3>Lilt</h3>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
            <div class="box">
              <x3d id="third" data-id="tab-nine3">
                <scene>
                  <inline url="assets/X3d/3D_models/Sprite_Can/sprite_can_x3d.x3d"></inline>
                </scene>
              </x3d>
              <h3>Sprite</h3>
            </div>
          </div>
        </div>
        <!-- End integrated x3d model html dome code -->
      </div>
    </section><!-- End Values Section -->


    <!-- Hidden Section  -->
    <section id="product" class="product d-none">
      <div class="container-fluid" data-aos="fade-up">
        <div class="row justify-content-center">
          <div class="col-9 col-lg-9">
            <div class="tab-content">
              <!-- start tab content -->
              <div class="tab-pane med-text fade in" id="tab-nine1">
                <div class="row row-cols-2 row-cols-lg-2 row-cols-sm-2 justify-content-center" style="border: 1px solid black;">
                  <div class="col">
                    <!-- start feature box item -->
                    <div class="feature-box">
                      <x3d width="500px" height="650px">
                        <scene>
                          <inline url="assets/X3d/3D_models/Coke_Can/coke_can_x3d.x3d"></inline>
                        </scene>
                      </x3d>
                      <h3>Coca Cola</h3>
                      <div class="feature-box-overlay bg-white border-radius-6px"></div>
                    </div>
                    <!-- end feature box item -->
                  </div>
                </div>
              </div>
              <!-- end tab content -->

              <!-- start tab content -->
              <div class="tab-pane fade in" id="tab-nine2">
                <div class="row row-cols-2 row-cols-lg-2 row-cols-sm-2 justify-content-center" style="border: 1px solid black;">
                  <div class="col">
                    <!-- start feature box item -->
                    <div class="feature-box">
                      <x3d width="500px" height="650px">
                        <scene>
                          <inline url="assets/X3d/3D_models/Lilt_can/Lilt_can_x3d.x3d"></inline>
                        </scene>
                      </x3d>
                      <h3>Lilt</h3>
                      <div class="feature-box-overlay bg-white border-radius-6px"></div>
                    </div>
                    <!-- end feature box item -->
                  </div>
                </div>
              </div>
              <!-- end tab content -->

              <!-- start tab content -->
              <div class="tab-pane fade in" id="tab-nine3">
                <div class="row row-cols-2 row-cols-lg-2 row-cols-sm-2 justify-content-center" style="border: 1px solid black;">
                  <div class="col">
                    <!-- start feature box item -->
                    <div class="feature-box">
                      <x3d width="500px" height="650px">
                        <scene>
                          <inline url="assets/X3d/3D_models/Sprite_Can/sprite_can_x3d.x3d"></inline>
                        </scene>
                      </x3d>
                      <h3>Sprite</h3>
                      <div class="feature-box-overlay bg-white border-radius-6px"></div>
                    </div>
                    <!-- end feature box item -->
                  </div>
                </div>
              </div>
              <!-- end tab content -->
            </div>
          </div>

          <div class="col-3 col-lg-3 tab-style-05">
            <div class="tab-box">
              <!-- start tab navigation -->
              <ul class="nav flex-column nav-tabs margin-7-rem-bottom md-margin-5-rem-bottom xs-margin-15px-lr align-items-center justify-content-center font-weight-500 text-uppercase">
                <li class="nav-item alt-font"><a class="nav-link" href="#tab-nine1" data-bs-toggle="tab"><img src="assets/img/cocacola1.png" class="" alt=""></a></li>
                <li class="nav-item alt-font"><a class="nav-link" href="#tab-nine2" data-bs-toggle="tab"><img src="assets/img/cocacola1.png" class="" alt=""></a></li>
                <li class="nav-item alt-font"><a class="nav-link" href="#tab-nine3" data-bs-toggle="tab"><img src="assets/img/cocacola1.png" class="" alt=""></a></li>
              </ul>
              <!-- end tab navigation -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="text-section d-none">
      <div class="container">
        <div class="row">
          <div class="col-lg-l2">
            <p>What is Lorem Ipsum?
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

            <p>Why do we use it?
              It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>

            <p>Where does it come from?
              Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

            <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>

            <p>Where can I get some?
              There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->







  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-5 col-md-12 footer-info">
            <a href="index.html" class="logo d-flex align-items-center">
              <img src="assets/img/cocacola1.png" alt="">
              <span>Coca Cola</span>
            </a>
            <p>About summary of company details.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>

          <div class="col-lg-2 col-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
            <h4>Contact Us</h4>
            <p>
              <strong>Phone:</strong> 0000000<br>
              <strong>Email:</strong> info@example.com<br>
            </p>

          </div>

        </div>
      </div>
    </div>
  </footer>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>



  <!-- ======= Routine JS for SPA ======= -->

  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <!-- Vendor JS Files -->
  <!-- <script src="assets/vendor/purecounter/purecounter.js"></script> -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <!-- <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script> -->
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <!-- <script src="assets/vendor/php-email-form/validate.js"></script> -->

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <script type="text/javascript">
    $(document).ready(function($) {
      var e0 = $(document).find('.screen_data');
      var s1 = $(document).find('.screen_home').html();
      e0.html(s1);

      $(document).on('click', '.btn_menu', function(event) {
        event.preventDefault();

        var screen_name = $(this).attr('screen_name');


        window.location.hash = '/' + screen_name;

        $(document).find('.screen_name').html(screen_name);

        if (screen_name == "home") {
          var s1 = $(document).find('.screen_home').html();
          e0.html(s1);
        } else if (screen_name == "coke") {
          var s1 = $(document).find('.screen_coke').html();
          e0.html(s1);
        } else if (screen_name == "sprite") {
          var s1 = $(document).find('.screen_sprite').html();
          e0.html(s1);
        } else if (screen_name == "lilt") {
          var s1 = $(document).find('.screen_lilt').html();
          e0.html(s1);
        } else if (screen_name == "extraWork") {
          var s1 = $(document).find('.screen_home').html();
          e0.html(s1);
        }

      });




    });

    $(document).ready(function($) {
      $(document).on('click', '#home', function(event) {
        if (!$(".text-section").hasClass("d-none")) {
          $(".text-section").addClass('d-none');
        }
        $(".products").removeClass('d-none');
        if (!$(".product").hasClass("d-none")) {
          $(".product").addClass('d-none');
        }

      });

      $(document).on('click', '#about-us', function(event) {
        $(".products").addClass('d-none');
        $(".product").addClass('d-none');
        $(".text-section").removeClass('d-none');
      });

    });
    //Tabs Work
    $(document).on('click', '#first', function(event) {
      var tab = $(this).attr('data-id');
      $(".products").addClass('d-none');
      $(".product").removeClass('d-none');
      $('#' + tab).addClass('show');
      $('#' + tab).addClass('active');
      $('a#' + tab).addClass('active');
      $('a[href="#' + tab + '"]').addClass('active');
    });

    $(document).on('click', '#second', function(event) {
      var tab = $(this).attr('data-id');
      $(".products").addClass('d-none');
      $(".product").removeClass('d-none');
      $('#' + tab).addClass('show');
      $('#' + tab).addClass('active');
      $('a[href="#' + tab + '"]').addClass('active');
    });

    $(document).on('click', '#third', function(event) {
      var tab = $(this).attr('data-id');
      $(".products").addClass('d-none');
      $(".product").removeClass('d-none');
      $('#' + tab).addClass('show');
      $('#' + tab).addClass('active');
      $('a[href="#' + tab + '"]').addClass('active');
    });
  </script>

</body>

</html>