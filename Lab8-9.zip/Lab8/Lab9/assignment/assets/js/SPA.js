$(".scrollto").click(function () {
    $(".scrollto").removeClass('active');
    $(this).addClass('active');
});
$(".home_nav").click(function () {
    $('.product>div').removeClass('active');
    //$('#coke').addClass('active');
});
$(".coke_nav").click(function () {
    $('.product>div').removeClass('active');
    $('#coke').addClass('active');
    $('#random').removeClass('active');
});
$(".sprite_nav").click(function () {
    $('.product>div').removeClass('active');
    $('#sprite').addClass('active');
    $('#random').removeClass('active');
});
$(".lilt_nav").click(function () {
    $('.product>div').removeClass('active');
    $('#lilt').addClass('active');
    $('#random').removeClass('active');
});
$(".extraWork_nav").click(function () {
    $('.product>div').removeClass('active');
    $('#extraWork').addClass('active');
});

$('.btn_change_color').click(function () {
    $('#hero').toggleClass('grayscale');
});

$('.btn_change_blur').click(function () {
    $('#hero').toggleClass('blur');
});

$('.btn_change_invert').click(function () {
    $('#hero').toggleClass('invert');
});

$('.btn_change_saturate').click(function () {
    $('#hero').toggleClass('saturate');
});