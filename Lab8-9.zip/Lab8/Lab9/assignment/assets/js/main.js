(function () {
    "use strict";

    /**
     * Easy selector helper function
     */
    const select = (el, all = false) => {
        el = el.trim()
        if (all) {
            return [...document.querySelectorAll(el)]
        } else {
            return document.querySelector(el)
        }
    }

    /**
     * Easy event listener function
     */
    const on = (type, el, listener, all = false) => {
        if (all) {
            select(el, all).forEach(e => e.addEventListener(type, listener))
        } else {
            select(el, all).addEventListener(type, listener)
        }
    }

    /**
     * Easy on scroll event listener
     */
    const onscroll = (el, listener) => {
        el.addEventListener('scroll', listener)
    }

    /**
     * Navbar links active state on scroll
     */
    let navbarlinks = select('#navbar .scrollto', true)
    const navbarlinksActive = () => {
        let position = window.scrollY + 200
        navbarlinks.forEach(navbarlink => {
            if (!navbarlink.hash) return
            let section = select(navbarlink.hash)
            if (!section) return
            if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
                navbarlink.classList.add('active')
            } else {
                navbarlink.classList.remove('active')
            }
        })
    }
    window.addEventListener('load', navbarlinksActive)
    onscroll(document, navbarlinksActive)

    /**
     * Scrolls to an element with header offset
     */
    const scrollto = (el) => {
        let header = select('#header')
        let offset = header.offsetHeight

        if (!header.classList.contains('header-scrolled')) {
            offset -= 10
        }

        let elementPos = select(el).offsetTop
        window.scrollTo({
            top: elementPos - offset,
            behavior: 'smooth'
        })
    }

    /**
     * Toggle .header-scrolled class to #header when page is scrolled
     */
    let selectHeader = select('#header')
    if (selectHeader) {
        const headerScrolled = () => {
            if (window.scrollY > 100) {
                selectHeader.classList.add('header-scrolled')
            } else {
                selectHeader.classList.remove('header-scrolled')
            }
        }
        window.addEventListener('load', headerScrolled)
        onscroll(document, headerScrolled)
    }

    /**
     * Back to top button
     */
    let backtotop = select('.back-to-top')
    if (backtotop) {
        const toggleBacktotop = () => {
            if (window.scrollY > 100) {
                backtotop.classList.add('active')
            } else {
                backtotop.classList.remove('active')
            }
        }
        window.addEventListener('load', toggleBacktotop)
        onscroll(document, toggleBacktotop)
    }

    /**
     * Mobile nav toggle
     */
    on('click', '.mobile-nav-toggle', function (e) {
        select('#navbar').classList.toggle('navbar-mobile')
        this.classList.toggle('bi-list')
        this.classList.toggle('bi-x')
    })

    /**
     * Mobile nav dropdowns activate
     */
    on('click', '.navbar .dropdown > a', function (e) {
        if (select('#navbar').classList.contains('navbar-mobile')) {
            e.preventDefault()
            this.nextElementSibling.classList.toggle('dropdown-active')
        }
    }, true)

    /**
     * Scrool with ofset on links with a class name .scrollto
     */
    on('click', '.scrollto', function (e) {
        if (select(this.hash)) {
            e.preventDefault()

            let navbar = select('#navbar')
            if (navbar.classList.contains('navbar-mobile')) {
                navbar.classList.remove('navbar-mobile')
                let navbarToggle = select('.mobile-nav-toggle')
                navbarToggle.classList.toggle('bi-list')
                navbarToggle.classList.toggle('bi-x')
            }
            scrollto(this.hash)
        }
    }, true)

    /**
     * Scroll with ofset on page load with hash links in the url
     */
    window.addEventListener('load', () => {
        if (window.location.hash) {
            if (select(window.location.hash)) {
                scrollto(window.location.hash)
            }
        }
    })

    /**
     * Animation on scroll
     */
    function aos_init() {
        AOS.init({
            duration: 1000,
            easing: "ease-in-out",
            once: true,
            mirror: false
        });
    }

    window.addEventListener('load', () => {
        aos_init();
    });

    // view stuff

    fetch("./backend/controller.php/extraWork").then(response => response.json().then(json => {
        if (response.ok) {
            document.querySelector("#extraWorkTitle").textContent = json.title;
            document.querySelector("#extraWorkDescription").textContent = json.description;
        }
    }))


    fetch("./backend/controller.php/imageGallery").then(response => response.json().then(json => {
        if (response.ok) {
            document.querySelector("#cokeCards").innerHTML = "";
            for (let i = 0; i < json.length; i++) {
/*                document.querySelector("#cokeCards").innerHTML += `
                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="box">
                        <div id="${json[i].nav} flex justify-content-center">
                            <img src="${json[i].image}" width="300px" height="300px">
                        </div>
                        <h3>${json[i].title}</h3>
                        <p>${json[i].description}</p>
                    </div>
                </div
                `;*/

                let firstDiv = document.createElement("div");
                firstDiv.className = "col-lg-4";
                firstDiv.setAttribute("data-aos-delay", "200");
                firstDiv.setAttribute("data-aos", "fade-up")

                let secondDiv = document.createElement("div");
                secondDiv.className = "box";
                firstDiv.appendChild(secondDiv);
                let thirdDiv = document.createElement("div");
                thirdDiv.addEventListener("click", () => {
                    $('#coke').removeClass('active');
                    $('#sprite').removeClass('active');
                    $('#lilt').removeClass('active');
                    $('#random').addClass('active');
                    // document.querySelector("#xModel").innerHTML =  `
                    //     <x3d mapDEFToID="true" nameSpaceName="model" width="500px" height="500px" id="modelContainer3">
                    //         <scene>
                    //           <inline url="assets/X3d/3D_models/Sprite_Can/sprite_can_x3d.x3d"></inline>
                    //         </scene>
                    //      </x3d>
                    // `;
                    document.querySelector("#xModel").setAttribute("url", json[i].url);
                });

                let image = document.createElement("img");
                image.src = json[i].image;

                let h3 = document.createElement("h3");
                h3.textContent = json[i].title;

                let p = document.createElement("p");
                p.textContent = json[i].description;

                thirdDiv.appendChild(image);
                secondDiv.appendChild(thirdDiv);
                secondDiv.appendChild(h3);
                secondDiv.appendChild(p);
                document.querySelector("#cokeCards").appendChild(firstDiv);
            }
        }
    }))







    var counter = 0;

    function changeLook() {
        document.getElementById('theme').style.background = "#77777";
        document.getElementById('theme').style.color = "000000";
    }

    function countUp() {
        counter += 1;
        document.getElementById('result').innerHTML = counter;
    }

    function changeColour(newColour) {
        var element = document.getElementById("paral");
        element.style.color = newColour;
    }



})();