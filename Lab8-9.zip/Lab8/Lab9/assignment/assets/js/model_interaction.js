
function wireframe(val)
{
    var e = document.getElementById('modelContainer'+val);
    e.runtime.togglePoints(true);
    e.runtime.togglePoints(true);
}


var lightOn = true;
function headLight()
{
    lightOn = !lightOn;
    document.getElementById('model__headlight').setAttribute('Headlight', lightOn.toString());
}
function cameraFront()
{
    document.getElementById('model__CameraFront').setAttribute('bind', 'true');
}
function cameraBack()
{
    document.getElementById('model__CameraBack').setAttribute('bind', 'true');
}
function cameraLeft()
{
    document.getElementById(val+'__CameraLeft').setAttribute('bind', 'true');
}
function cameraRight()
{
    document.getElementById('model__CameraRight').setAttribute('bind', 'true');
}

