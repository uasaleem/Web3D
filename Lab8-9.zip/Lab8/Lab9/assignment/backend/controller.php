<?php
include_once "model.php";
$pageURL = $_SERVER['REQUEST_URI'];
$pageURL = substr($pageURL,strrpos($pageURL,'controller.php')+15);

header("Content-type: application/json");

function extraWork() {
    $data = getExtraWorkData();
    if (is_string($data)) {
        http_response_code(500);
        json_encode(array("error" => $data));
        exit;
    }
    return json_encode($data);
}

function imageGallery() {
    $data = getImageGallery();
    if (is_string($data)) {
        http_response_code(500);
        json_encode(array("error" => $data));
        exit;
    }
    return json_encode($data);
}

function x3dModels() {
    $data = getX3dModels();
    if (is_string($data)) {
        http_response_code(500);
        json_encode(array("error" => $data));
        exit;
    }
    return json_encode($data);
}


echo $pageURL();
// calls the function with the name coming from the end of the url
// the end of the url function needs to exist though for this to work.