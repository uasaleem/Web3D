<?php


function dbConn () {
    try {
        return new PDO('sqlite:../assets/coke-database.db');
    } catch(PDOException $e) {
        return "Connection failed: " . $e->getMessage();
    }
}

function getExtraWorkData() {
    # the home data
    $conn = dbConn();

    if (is_string($conn)) {
        return $conn;
    }
    $sql = "SELECT * FROM extra_work";
    $result = $conn->query($sql);
    return $result->fetch(PDO::FETCH_ASSOC);
}

function getX3dModels() {
    # the home data
    $conn = dbConn();

    if (is_string($conn)) {
        return $conn;
    }
    $sql = "SELECT * FROM x3dModels";
    $result = $conn->query($sql);
    return $result->fetchAll(PDO::FETCH_ASSOC);
}

function getImageGallery() {
    # the home data
    $conn = dbConn();

    if (is_string($conn)) {
        return $conn;
    }
    $sql = "SELECT image_gallery.image, x3dM.Description, x3dM.url FROM image_gallery LEFT JOIN x3dModels x3dM on image_gallery.title = x3dM.galleryName";
    $result = $conn->query($sql);
    return $result->fetchAll(PDO::FETCH_ASSOC);
}