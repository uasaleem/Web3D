<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Web3D</title>
  <meta content="" name="description">

  <meta content="" name="keywords">

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="https://fonts.cdnfonts.com/css/coca-cola-ii" rel="stylesheet">
  <link href="./assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="./assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="./assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="./assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="./assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="./assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="./assets/css/style.css" rel="stylesheet">

  <!-- For x3d model showing -->
  <!--<link rel='stylesheet' type='text/css' href='https://www.x3dom.org/x3dom/release/x3dom.css'> -->
  <link href="./assets/vendor/x3d/x3d.css" ref="stylesheet">

  <!--Ensure no mixed content error from HTTP-->
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <script type='text/javascript' src='http://www.x3dom.org/x3dom/release/x3dom.js'></script>
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <h2 class ="cola">Cola Cola</h2>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto home_nav active" href="javascript:void(0);">Home</a></li>
          <li><a class="nav-link coke_nav scrollto" href="javascript:void(0);">Coke</a></li>
          <li><a class="nav-link sprite_nav scrollto" href="javascript:void(0);">Sprite</a></li>
          <li><a class="nav-link lilt_nav scrollto" href="javascript:void(0);">Lilt</a></li>
          <li><a class="nav-link scrollto" href="">Github</a></li>
          <li><a class="getstarted extraWork_nav scrollto" href="javascript:void(0);">Extra Work</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center">
    <div class="container">
      <div class="row">
        <div class="col-lg-9 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up">X3d models</h1>
          <h2 data-aos="fade-up" data-aos-delay="400">Test</h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <div class="text-center text-lg-start">
              <a href='javascript:countUp()'
                class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                <span>Click here to count</span>
                <div id="result"></div>
                <i class="bi bi-arrow-right"></i>
              </a>

              <a href='javascript:void(0)'
                class="btn-get-started btn_change_color scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                <span>Click here to change color</span>
                <i class="bi bi-arrow-right"></i>
              </a>

              <a href='javascript:void(0)'
                class="btn-get-started btn_change_blur scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                <span>Click here to blur</span>
                <i class="bi bi-arrow-right"></i>
              </a>

              <a href='javascript:void(0)'
                class="btn-get-started btn_change_invert scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                <span>Click here to invert</span>
                <i class="bi bi-arrow-right"></i>
              </a>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= Values Section ======= -->
    <section id="values" class="values">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Product Gallery</h2>
          <p>Drinks</p>
        </header>
        <div class="row" id="cokeCards"> <!--id = cards --> </div>
      </div>
    </section><!-- End Values Section -->

    <section id="product" class="product">
        <!-- Hidden Coke Section -->
        <div class="container-fluid" id="coke" data-aos="fade-up">
        <div class="row justify-content-center">
          <div class="col-6 col-lg-6 box">
            <div class="box" id = "cokeCanX3D">
              <x3d width='500px' height='400px' id = "modelContainer1">
                <scene>
                  <inline mapDEFToID="true" nameSpaceName="model" url="assets/X3d/3D_models/Coke_Can/coke_can_x3d.x3d"></inline>
                </scene>
              </x3d>
              <button class="btn btn-primary" href="#" onclick="cameraFront()">Camera Front</button>
              <button class="btn btn-primary" href="#" onclick="cameraBack()">Camera Back</button>
              <button class="btn btn-primary" href="#" onclick="cameraLeft()">Camera Left</button>
              <button class="btn btn-primary" href="#" onclick="headlight()">Headlight</button>
              <button class="btn btn-primary" href="#" onclick="wireframe('1')">WireFrame</button>
            </div>
          </div>

          <div class="col-6 col-lg-6">
            <div class="box" id="cokeBottleX3D">
              <x3d width="500px" height="500px" id="modelContainer2">
                <scene>
                  <inline mapDEFToID="true" nameSpaceName="model" url="assets/X3d/3D_models/coke_bottle/coke_bottle_x3d.x3d"></inline>
                </scene>
              </x3d>
              <button class="btn btn-primary" href="#" onclick="cameraFront()">Camera Front</button>
              <button class="btn btn-primary" href="#" onclick="cameraBack()">Camera Back</button>
              <button class="btn btn-primary" href="#" onclick="cameraLeft()">Camera Left</button>
              <button class="btn btn-primary" href="#" onclick="headlight()">Headlight</button>
              <button class="btn btn-primary" href="#" onclick="wireframe('2')">WireFrame</button>
            </div>
          </div>
        </div>
      </div>
        <!--end tab content -->

        <!--Hidden Sprite Container -->
        <div class="container-fluid" id="sprite" data-aos="fade-up">
        <div class="row justify-content-center">
          <div class="col-4 col-lg-4">
            <div class="box">
              <x3d mapDEFToID="true" nameSpaceName="model" width="500px" height="500px" id="modelContainer3">
                <scene>
                  <inline url="assets/X3d/3D_models/Sprite_Can/sprite_can_x3d.x3d"></inline>
                </scene>
              </x3d>
              <button class="btn btn-primary" href="#" onclick="cameraFront()">Camera Front</button>
              <button class="btn btn-primary" href="#" onclick="cameraBack()">Camera Back</button>
              <button class="btn btn-primary" href="#" onclick="headlight()">Headlight</button>
              <button class="btn btn-primary" href="#" onclick="wireframe('3')">WireFrame</button>
            </div>
          </div>
          <div class="col-4 col-lg-4 justify-content-center">
            <div class="box">
              <x3d mapDEFToID="true" nameSpaceName="model" width="500px" height="500px" id="modelContainer4">
                <scene>
                  <inline url="assets/X3d/3D_models/Sprite_Bottle/Sprite_bottle.x3d"></inline>
                </scene>
              </x3d>
              <button class="btn btn-primary" href="#" onclick="cameraFront()">Camera Front</button>
              <button class="btn btn-primary" href="#" onclick="cameraBack()">Camera Back</button>
              <button class="btn btn-primary" href="#" onclick="headlight()">Headlight</button>
              <button class="btn btn-primary" href="#" onclick="wireframe('4')">WireFrame</button>
            </div>
          </div>
        </div>
        </div>
        <!--<end tab content -->

        <!--Hidden Lilt Container -->
        <div class="container-fluid" id="lilt" data-aos="fade-up">
        <div class="row justify-content-center">
          <div class="col-6 col-lg-6">
            <div class="box">
              <x3d mapDEFToID="true" nameSpaceName="model" width="500px" height="500px" id="modelContainer5">-
                <scene>-
                  <inline url="assets/X3d/Lilt_Can/lilt_can_x3d.x3d"></inline>-
                </scene>
              </x3d>
              <button class="btn btn-primary" href="#" onclick="cameraFront()">Camera Front</button>
              <button class="btn btn-primary" href="#" onclick="cameraLeft()">Camera Back</button>
              <button class="btn btn-primary" href="#" onclick="headlight()">Headlight</button>
              <button class="btn btn-primary" href="#" onclick="wireframe('5')">WireFrame</button>
              <div class="feature-box-overlay bg-white border-radius-6px"></div>
            </div>
          </div>
          <div class="col-6 col-lg-6">
            <div class="box">
            <x3d mapDEFToID="true" nameSpaceName="model"  width="500px" height="500px" id="modelContainer6">
                <scene>
                  <inline url="assets/X3d/3D_models/lilt_bottle/lilt_bottle_x3d.x3d"></inline>
                </scene>
              </x3d>
              <button class="btn btn-primary" href="#" onclick="cameraFront()">Camera Front</button>
              <button class="btn btn-primary" href="#" onclick="cameraBack()">Camera Back</button>
              <button class="btn btn-primary" href="#" onclick="headlight()">Headlight</button>
              <button class="btn btn-primary" href="#" onclick="wireframe('6')">WireFrame</button>
              <div class="feature-box-overlay bg-white border-radius-6px"></div>
            </div>
          </div>
        </div>
      </div>

        <div class="container-fluid" id="random" data-aos="fade-up">
            <div class="row justify-content-center">
                <div class="col-6 col-lg-6">
                    <div class="box">
                        <div>
                            <x3d mapDEFToID="true" nameSpaceName="model" width="500px" height="500px" id="modelContainer3">
                                <scene>
                                    <inline id="xModel" url="assets/X3d/3D_models/Sprite_Can/sprite_can_x3d.x3d"></inline>
                                </scene>
                            </x3d>
                        </div>
                        <div class="feature-box-overlay bg-white border-radius-6px"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Hidden ExtraWork section-->
    <section class = "container-fluid" id="extraWork" data-aos = "fade-up">
        <div class="row">
          <div class="col-lg-l2">
            <h2 id="extraWorkTitle"></h2>
            <p id="extraWorkDescription"></p>
          </div>
        </div>
    </section>
  </main><!-- End #main -->


  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="./assets/vendor/aos/aos.js"></script>
  <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="./assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="./assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="./assets/js/main.js"></script>
  <script src="./assets/js/model_interaction.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <script src="./assets/js/SPA.js"></script>
</body>
</html>